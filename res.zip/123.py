import cv2
import numpy as np
import mss

def sift_match_on_screen(template_path, min_match_count=10, tolerance=0.75):
    # 加载模板图（小图）
    img_template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
    if img_template is None:
        print("❌ 无法加载模板图像")
        return None

    # 截取全屏
    with mss.mss() as sct:
        monitor = sct.monitors[1]
        screenshot = np.array(sct.grab(monitor))[:, :, :3]
        img_screen = cv2.cvtColor(screenshot, cv2.COLOR_RGB2GRAY)

    # 初始化 SIFT，限制特征数（速度更快）
    sift = cv2.SIFT_create(nfeatures=200)

    # 提取关键点与描述符
    kp1, des1 = sift.detectAndCompute(img_template, None)
    kp2, des2 = sift.detectAndCompute(img_screen, None)

    if des1 is None or des2 is None:
        print("❌ 特征提取失败")
        return None

    # 使用 FLANN 匹配器（替代暴力匹配）
    index_params = dict(algorithm=1, trees=5)  # 使用 KD-Tree
    search_params = dict(checks=50)
    flann = cv2.FlannBasedMatcher(index_params, search_params)
    matches = flann.knnMatch(des1, des2, k=2)

    # 低e比匹配（Lowe's ratio test）
    good = [m for m, n in matches if m.distance < tolerance * n.distance]

    if len(good) >= min_match_count:
        print(f"✅ 匹配成功：{len(good)} 个关键点")

        # 提取匹配坐标
        src_pts = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        dst_pts = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)

        # 单应矩阵
        M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)

        if M is not None:
            h, w = img_template.shape
            corners = np.float32([[0,0], [w,0], [w,h], [0,h]]).reshape(-1, 1, 2)
            dst = cv2.perspectiveTransform(corners, M)

            # 返回屏幕上的实际坐标（整数）
            result_coords = [(int(p[0][0]), int(p[0][1])) for p in dst]
            print("📌 匹配区域角点坐标:", result_coords)
            return result_coords
        else:
            print("❌ 无法计算单应性")
            return None
    else:
        print(f"❌ 匹配点不足（{len(good)}/{min_match_count}）")
        return None

# 示例调用
coords = sift_match_on_screen("small.png")
print("📋 最终返回坐标:", coords)